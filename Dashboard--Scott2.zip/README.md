## React Dashboard

### Development

```
npm install
npm run dev for development server
npm start For Production server
```

Server will be running on [http://localhost:8080/](http://localhost:8080/)
