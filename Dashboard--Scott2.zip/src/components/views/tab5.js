import React from 'react';
import { Link } from 'react-router'

class Tab5 extends React.Component { 
    componentDidMount() {    
      }          
            
  render() {
        return (
     <div id="tab5" className="tab-content">
		      						<h1 className="title">Chris account setting </h1>
	      							<div className="box">5</div>
	</div>
        );
    }
  
}

export default Tab5;
