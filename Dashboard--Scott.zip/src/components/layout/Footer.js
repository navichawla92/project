import React from 'react';

class Footer extends React.Component {
 
  render() {
        return (
        <div>
           	<footer className="footer">
           	<div className="container text-center">
			&copy;Planswell Holdings Inc.
		  </div>
           	</footer>
          
        
  	     </div>
        );
    }
  
}

export default Footer;
